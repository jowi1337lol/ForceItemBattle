package de.forceitembattle;

import de.forceitembattle.commands.FibCommand;
import de.forceitembattle.commands.FibAdminCommand;
import de.forceitembattle.game.GameManager;
import de.forceitembattle.gui.GuiListener;
import org.bukkit.plugin.java.JavaPlugin;

public class ForceItemBattle extends JavaPlugin {

    private static ForceItemBattle instance;
    private GameManager gameManager;

    @Override
    public void onEnable() {
        instance = this;
        gameManager = new GameManager(this);

        // Commands registrieren
        getCommand("fib").setExecutor(new FibCommand(this));
        getCommand("fibadmin").setExecutor(new FibAdminCommand(this));

        // Events registrieren
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(gameManager, this);

        getLogger().info("ForceItemBattle gestartet!");
    }

    @Override
    public void onDisable() {
        if (gameManager != null && gameManager.isRunning()) {
            gameManager.stopGame(null);
        }
        getLogger().info("ForceItemBattle gestoppt!");
    }

    public static ForceItemBattle getInstance() {
        return instance;
    }

    public GameManager getGameManager() {
        return gameManager;
    }
}
