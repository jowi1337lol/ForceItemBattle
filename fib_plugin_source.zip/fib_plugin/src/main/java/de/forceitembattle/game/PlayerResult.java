package de.forceitembattle.game;

import java.util.UUID;

public class PlayerResult {
    private final String name;
    private final int score;
    private final UUID uuid;

    public PlayerResult(String name, int score, UUID uuid) {
        this.name = name;
        this.score = score;
        this.uuid = uuid;
    }

    public String getName() { return name; }
    public int getScore() { return score; }
    public UUID getUuid() { return uuid; }
}
