package de.forceitembattle.game;

import de.forceitembattle.ForceItemBattle;
import de.forceitembattle.gui.MainGui;
import de.forceitembattle.gui.ResultGui;
import de.forceitembattle.util.ItemList;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.*;

import java.util.*;

public class GameManager implements Listener {

    private final ForceItemBattle plugin;

    private boolean running = false;
    private boolean paused = false;
    private int timeSeconds = 90 * 60; // Default 90 Minuten
    private int timeLeft = 0;

    private BukkitTask timerTask;
    private BossBar itemBossBar;
    private BossBar jokerBossBar;

    private final Map<UUID, PlayerData> playerData = new HashMap<>();
    private final List<String> itemPool;

    private Scoreboard scoreboard;
    private Objective scoreObjective;

    public GameManager(ForceItemBattle plugin) {
        this.plugin = plugin;
        this.itemPool = ItemList.getAllItems();
        setupScoreboard();
    }

    private void setupScoreboard() {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        scoreboard = manager.getNewScoreboard();
        scoreObjective = scoreboard.registerNewObjective(
            "fib_score", Criteria.DUMMY,
            Component.text("§6Punkte").decoration(TextDecoration.ITALIC, false)
        );
        scoreObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
    }

    public void startGame(Player starter) {
        if (running) {
            starter.sendMessage(Component.text("[FIB] Ein Spiel läuft bereits!", NamedTextColor.RED));
            return;
        }

        running = true;
        paused = false;
        timeLeft = timeSeconds;
        playerData.clear();

        // Alle Online-Spieler initialisieren
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData data = new PlayerData(p.getUniqueId(), p.getName());
            playerData.put(p.getUniqueId(), data);
            assignNewItem(p);
            p.setScoreboard(scoreboard);
            scoreObjective.getScore(p.getName()).setScore(0);
        }

        // BossBars erstellen
        itemBossBar = Bukkit.createBossBar("", BarColor.YELLOW, BarStyle.SOLID);
        jokerBossBar = Bukkit.createBossBar("§c§lJoker: 3/3", BarColor.RED, BarStyle.SEGMENTED_6);
        jokerBossBar.setProgress(1.0);

        for (Player p : Bukkit.getOnlinePlayers()) {
            itemBossBar.addPlayer(p);
            jokerBossBar.addPlayer(p);
        }

        // Timer starten
        timerTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);

        // Ankündigung
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendTitle(
                "§6§l⚔ Force Item Battle! ⚔",
                "§eFinde die Items!",
                10, 60, 20
            );
            p.sendMessage(Component.text("[FIB] Das Spiel startet! Joker: /fib joker | Skip: /fib skip", NamedTextColor.GREEN));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
    }

    private void tick() {
        if (paused) return;
        timeLeft--;

        // Actionbar für alle
        int mins = timeLeft / 60;
        int secs = timeLeft % 60;
        String timeStr = String.format("§6⏱ %dm %02ds   §7|   §a✔ Punkte: §f%%s   §7|   §c🃏 §f%%s", mins, secs);

        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData data = playerData.get(p.getUniqueId());
            if (data != null) {
                p.sendActionBar(Component.text(
                    String.format("§6⏱ %dm %02ds   §7|   §a✔ §f%d Punkte   §7|   §c🃏 §f%d/3",
                        mins, secs, data.getScore(), data.getJokers())
                ));
            }
        }

        // Warnungen
        if (timeLeft == 300) broadcastMessage("§e[FIB] ⏱ Noch 5 Minuten!", Sound.BLOCK_NOTE_BLOCK_BELL);
        if (timeLeft == 60) broadcastMessage("§c[FIB] ⏱ Noch 1 Minute!", Sound.BLOCK_NOTE_BLOCK_BELL);
        if (timeLeft == 30) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.sendTitle("§c30 Sekunden!", "", 5, 30, 10);
            }
        }

        // Bossbar Zeit aktualisieren
        if (itemBossBar != null) {
            itemBossBar.setProgress(Math.max(0, (double) timeLeft / timeSeconds));
        }

        // Zeit abgelaufen
        if (timeLeft <= 0) {
            endGame();
        }
    }

    public void endGame() {
        if (!running) return;
        running = false;

        if (timerTask != null) timerTask.cancel();

        // Bossbars entfernen
        if (itemBossBar != null) { itemBossBar.removeAll(); itemBossBar = null; }
        if (jokerBossBar != null) { jokerBossBar.removeAll(); jokerBossBar = null; }

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendTitle("§c§lZEIT IST UM!", "§eDie Ergebnisse werden angezeigt...", 10, 80, 20);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }

        // Ergebnis-GUI nach 3 Sekunden öffnen
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                new ResultGui(plugin, getResults()).open(p);
            }
        }, 60L);
    }

    public void stopGame(Player stopper) {
        if (!running) {
            if (stopper != null) stopper.sendMessage(Component.text("[FIB] Kein Spiel läuft!", NamedTextColor.RED));
            return;
        }
        running = false;
        paused = false;

        if (timerTask != null) timerTask.cancel();
        if (itemBossBar != null) { itemBossBar.removeAll(); itemBossBar = null; }
        if (jokerBossBar != null) { jokerBossBar.removeAll(); jokerBossBar = null; }

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendTitle("§c§lSpiel beendet!", "", 10, 40, 20);
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        broadcastMessage("§c[FIB] Das Spiel wurde beendet!", Sound.ENTITY_VILLAGER_NO);
    }

    public void pauseGame(Player p) {
        if (!running) {
            p.sendMessage(Component.text("[FIB] Kein Spiel läuft!", NamedTextColor.RED));
            return;
        }
        paused = !paused;
        String msg = paused ? "§e[FIB] ⏸ Spiel pausiert!" : "§a[FIB] ▶ Spiel fortgesetzt!";
        broadcastMessage(msg, Sound.BLOCK_NOTE_BLOCK_BELL);
    }

    public void resetGame(Player p) {
        for (Player online : Bukkit.getOnlinePlayers()) {
            PlayerData data = playerData.get(online.getUniqueId());
            if (data != null) {
                data.setScore(0);
                data.setJokers(3);
                scoreObjective.getScore(online.getName()).setScore(0);
                assignNewItem(online);
            }
        }
        if (jokerBossBar != null) {
            jokerBossBar.setTitle("§c§lJoker: 3/3");
            jokerBossBar.setProgress(1.0);
        }
        // Timer neu setzen
        timeLeft = timeSeconds;
        broadcastMessage("§a[FIB] Reset! Neue Items, volle Joker, Zeit neu!", Sound.ENTITY_PLAYER_LEVELUP);
    }

    public void useJoker(Player p) {
        if (!running) {
            p.sendMessage(Component.text("[FIB] Kein Spiel läuft!", NamedTextColor.RED));
            return;
        }
        PlayerData data = playerData.get(p.getUniqueId());
        if (data == null) return;

        if (data.getJokers() <= 0) {
            p.sendMessage(Component.text("[FIB] Keine Joker mehr!", NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        data.setJokers(data.getJokers() - 1);
        assignNewItem(p);

        // Joker Bossbar updaten (zeigt min Joker aller Spieler)
        updateJokerBar();

        String msg = String.format("§c§lJoker benutzt! Noch %d übrig.", data.getJokers());
        p.sendActionBar(Component.text(msg));
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);

        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage(Component.text(
                String.format("[FIB] §b%s§r nutzt einen §cJoker§r! Noch §c%d§r übrig.",
                    p.getName(), data.getJokers())
            ));
        }
    }

    public void skipItem(Player p) {
        if (!running) {
            p.sendMessage(Component.text("[FIB] Kein Spiel läuft!", NamedTextColor.RED));
            return;
        }
        assignNewItem(p);
        p.sendActionBar(Component.text("§bItem übersprungen (kein Punkt)"));
        p.sendMessage(Component.text("[FIB] Item übersprungen!", NamedTextColor.AQUA));
    }

    public void assignNewItem(Player p) {
        if (itemPool.isEmpty()) return;
        String item = itemPool.get(new Random().nextInt(itemPool.size()));
        PlayerData data = playerData.get(p.getUniqueId());
        if (data != null) data.setCurrentItem(item);

        // Item-Namen schön formatieren
        String displayName = formatItemName(item);

        // Bossbar updaten
        if (itemBossBar != null) {
            itemBossBar.setTitle("§6§l🎯 Finde: §e" + displayName);
        }

        // Chat Nachricht
        p.sendMessage(Component.text("§6[FIB] §eFinde: §a§l" + displayName));
        p.playSound(p.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1f, 1f);
    }

    private void updateJokerBar() {
        if (jokerBossBar == null) return;
        int minJokers = 3;
        for (PlayerData data : playerData.values()) {
            minJokers = Math.min(minJokers, data.getJokers());
        }
        jokerBossBar.setTitle(String.format("§c§lJoker: %d/3", minJokers));
        jokerBossBar.setProgress(minJokers / 3.0);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        if (running) {
            itemBossBar.addPlayer(p);
            jokerBossBar.addPlayer(p);
            if (!playerData.containsKey(p.getUniqueId())) {
                PlayerData data = new PlayerData(p.getUniqueId(), p.getName());
                playerData.put(p.getUniqueId(), data);
                assignNewItem(p);
            }
            p.setScoreboard(scoreboard);
        }
    }

    public void checkInventory(Player p) {
        if (!running || paused) return;
        PlayerData data = playerData.get(p.getUniqueId());
        if (data == null || data.getCurrentItem() == null) return;

        String needed = data.getCurrentItem();
        Material mat = Material.matchMaterial(needed);
        if (mat == null) {
            // Item nicht gefunden - neues zuweisen
            assignNewItem(p);
            return;
        }

        // Prüfe ob Spieler das Item hat
        if (p.getInventory().contains(mat)) {
            itemFound(p, data);
        }
    }

    private void itemFound(Player p, PlayerData data) {
        data.setScore(data.getScore() + 1);
        scoreObjective.getScore(p.getName()).setScore(data.getScore());

        p.sendActionBar(Component.text("§a§l✔ +1 Punkt!"));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);

        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage(Component.text(
                String.format("[FIB] §b%s§a hat ein Item gefunden! §7(%d Punkte)",
                    p.getName(), data.getScore())
            ));
        }

        assignNewItem(p);
    }

    public List<PlayerResult> getResults() {
        List<PlayerResult> results = new ArrayList<>();
        for (PlayerData data : playerData.values()) {
            Player p = Bukkit.getPlayer(data.getUuid());
            results.add(new PlayerResult(data.getName(), data.getScore(),
                p != null ? p.getUniqueId() : data.getUuid()));
        }
        results.sort((a, b) -> b.getScore() - a.getScore());
        return results;
    }

    private String formatItemName(String itemId) {
        String[] parts = itemId.replace("minecraft:", "").split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0)))
                  .append(part.substring(1).toLowerCase())
                  .append(" ");
            }
        }
        return sb.toString().trim();
    }

    private void broadcastMessage(String msg) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(Component.text(msg));
        }
    }

    private void broadcastMessage(String msg, Sound sound) {
        broadcastMessage(msg);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), sound, 1f, 1f);
        }
    }

    public boolean isRunning() { return running; }
    public boolean isPaused() { return paused; }
    public int getTimeSeconds() { return timeSeconds; }
    public void setTimeSeconds(int seconds) { this.timeSeconds = seconds; }
    public Map<UUID, PlayerData> getPlayerData() { return playerData; }
    public BossBar getItemBossBar() { return itemBossBar; }
}
