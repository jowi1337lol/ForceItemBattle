package de.forceitembattle.game;

import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private final String name;
    private int score;
    private int jokers;
    private String currentItem;

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
        this.score = 0;
        this.jokers = 3;
        this.currentItem = null;
    }

    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    public int getJokers() { return jokers; }
    public void setJokers(int jokers) { this.jokers = jokers; }
    public String getCurrentItem() { return currentItem; }
    public void setCurrentItem(String item) { this.currentItem = item; }
}
