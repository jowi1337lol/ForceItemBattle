package de.forceitembattle.commands;

import de.forceitembattle.ForceItemBattle;
import de.forceitembattle.gui.MainGui;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class FibAdminCommand implements CommandExecutor {

    private final ForceItemBattle plugin;

    public FibAdminCommand(ForceItemBattle plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }

        if (!p.hasPermission("fib.admin") && !p.isOp()) {
            p.sendMessage(Component.text("[FIB] Keine Berechtigung!", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            new MainGui(plugin).open(p);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "start" -> plugin.getGameManager().startGame(p);
            case "stop" -> plugin.getGameManager().stopGame(p);
            case "reset" -> plugin.getGameManager().resetGame(p);
            case "pause" -> plugin.getGameManager().pauseGame(p);
            case "skip" -> plugin.getGameManager().skipItem(p);
            case "joker" -> plugin.getGameManager().useJoker(p);
            default -> {
                p.sendMessage(Component.text("[FIB] Befehle: start|stop|reset|pause|skip|joker", NamedTextColor.YELLOW));
            }
        }

        return true;
    }
}
