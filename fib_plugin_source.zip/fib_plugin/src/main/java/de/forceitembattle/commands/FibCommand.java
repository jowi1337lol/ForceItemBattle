package de.forceitembattle.commands;

import de.forceitembattle.ForceItemBattle;
import de.forceitembattle.gui.MainGui;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class FibCommand implements CommandExecutor {

    private final ForceItemBattle plugin;

    public FibCommand(ForceItemBattle plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }

        if (args.length == 0) {
            // Hauptmenü öffnen
            new MainGui(plugin).open(p);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "joker" -> plugin.getGameManager().useJoker(p);
            case "skip" -> plugin.getGameManager().skipItem(p);
            default -> new MainGui(plugin).open(p);
        }

        return true;
    }
}
