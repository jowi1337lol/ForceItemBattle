package de.forceitembattle.util;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

public class ItemList {

    public static List<String> getAllItems() {
        List<String> items = new ArrayList<>();

        // Nur Items die in Survival erhältlich sind
        Material[] allMaterials = Material.values();
        for (Material mat : allMaterials) {
            if (isValidSurvivalItem(mat)) {
                items.add(mat.name().toLowerCase());
            }
        }

        return items;
    }

    private static boolean isValidSurvivalItem(Material mat) {
        // Nur echte Items (keine Blöcke die man nicht einsammeln kann, keine Creative-Only Items)
        if (!mat.isItem()) return false;
        if (mat.isAir()) return false;
        if (mat.name().contains("SPAWN_EGG")) return false;
        if (mat.name().contains("COMMAND_BLOCK")) return false;
        if (mat.name().contains("STRUCTURE")) return false;
        if (mat.name().contains("DEBUG")) return false;
        if (mat.name().contains("BARRIER")) return false;
        if (mat.name().contains("LIGHT")) return false;
        if (mat.name().contains("KNOWLEDGE_BOOK")) return false;
        if (mat.name().contains("BUNDLE") && mat.name().contains("OPEN")) return false;

        // Nur Items die man in Survival finden/craften kann
        switch (mat) {
            case BEDROCK:
            case END_PORTAL_FRAME:
            case END_PORTAL:
            case NETHER_PORTAL:
            case FIRE:
            case SOUL_FIRE:
            case VOID_AIR:
            case CAVE_AIR:
            case WATER:
            case LAVA:
            case PETRIFIED_OAK_SLAB:
            case REINFORCED_DEEPSLATE:
                return false;
            default:
                break;
        }

        return true;
    }
}
