package de.forceitembattle.gui;

import de.forceitembattle.ForceItemBattle;
import de.forceitembattle.game.PlayerResult;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

public class ResultGui {

    private final ForceItemBattle plugin;
    private final Inventory inv;
    private final List<PlayerResult> results;
    public static final String TITLE = "§6§l🏆 ERGEBNISSE";

    public ResultGui(ForceItemBattle plugin, List<PlayerResult> results) {
        this.plugin = plugin;
        this.results = results;
        this.inv = Bukkit.createInventory(null, 54, Component.text(TITLE));
        build();
    }

    private void build() {
        // Füller
        ItemStack gray = MainGui.makeItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, gray);

        // Titel
        inv.setItem(4, MainGui.makeItem(Material.NETHER_STAR,
            "§6§l🏆 FORCE ITEM BATTLE - ERGEBNIS",
            "§7Hier sind die Ergebnisse!"));

        // Plätze mit Player Heads
        int[] slots = {19, 22, 25, 28, 31, 34, 37, 40}; // Slots für bis zu 8 Spieler
        String[] medals = {"§6§l🥇 1. Platz", "§7§l🥈 2. Platz", "§c§l🥉 3. Platz",
                          "§e§l4. Platz", "§e§l5. Platz", "§e§l6. Platz",
                          "§e§l7. Platz", "§e§l8. Platz"};
        Material[] blocks = {Material.GOLD_BLOCK, Material.IRON_BLOCK,
                             Material.COPPER_BLOCK, Material.OAK_PLANKS,
                             Material.OAK_PLANKS, Material.OAK_PLANKS,
                             Material.OAK_PLANKS, Material.OAK_PLANKS};

        for (int i = 0; i < Math.min(results.size(), slots.length); i++) {
            PlayerResult result = results.get(i);
            int slot = slots[i];

            // Versuche Player Head zu erstellen
            ItemStack head = createPlayerHead(result, medals[i]);
            if (head != null) {
                inv.setItem(slot, head);
            } else {
                // Fallback: Block mit Spielername
                inv.setItem(slot, MainGui.makeItem(blocks[i],
                    medals[i] + " " + result.getName(),
                    "§7Punkte: §a§l" + result.getScore(),
                    "§7Spieler: §f" + result.getName()));
            }
        }

        // Buttons unten
        inv.setItem(46, MainGui.makeItem(Material.LIME_STAINED_GLASS_PANE,
            "§a§l▶ NEUES SPIEL", "§7Startet eine neue Runde"));
        inv.setItem(48, MainGui.makeItem(Material.ORANGE_STAINED_GLASS_PANE,
            "§6§l↺ RESET", "§7Alle Punkte zurücksetzen"));
        inv.setItem(49, MainGui.makeItem(Material.BARRIER,
            "§4§l✖ SCHLIESSEN", "§7Schließt dieses Menü"));
        inv.setItem(50, MainGui.makeItem(Material.WRITABLE_BOOK,
            "§b§lHAUPTMENÜ", "§7Zurück zum Hauptmenü"));
    }

    private ItemStack createPlayerHead(PlayerResult result, String medal) {
        try {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();

            // Spieler online?
            Player p = Bukkit.getPlayer(result.getUuid());
            if (p != null) {
                meta.setOwningPlayer(p);
            } else {
                meta.setOwnerProfile(Bukkit.createPlayerProfile(result.getUuid(), result.getName()));
            }

            meta.displayName(Component.text(medal + " §f" + result.getName())
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));

            meta.lore(List.of(
                Component.text("§7Punkte: §a§l" + result.getScore())
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                Component.text("§7Spieler: §f" + result.getName())
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)
            ));

            head.setItemMeta(meta);
            return head;
        } catch (Exception e) {
            return null;
        }
    }

    public void open(Player p) {
        p.openInventory(inv);
    }

    public Inventory getInventory() { return inv; }
}
