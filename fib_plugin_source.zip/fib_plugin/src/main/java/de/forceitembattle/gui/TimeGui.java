package de.forceitembattle.gui;

import de.forceitembattle.ForceItemBattle;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class TimeGui {

    private final ForceItemBattle plugin;
    private final Inventory inv;
    public static final String TITLE = "§e§l⏱ Zeit einstellen";

    public TimeGui(ForceItemBattle plugin) {
        this.plugin = plugin;
        this.inv = Bukkit.createInventory(null, 27, Component.text(TITLE));
        build();
    }

    private void build() {
        // Grauer Füller
        ItemStack gray = MainGui.makeItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, gray);

        // Titel
        inv.setItem(4, MainGui.makeItem(Material.CLOCK, "§e§l⏱ SPIELZEIT WÄHLEN", "§7Klicke eine Zeit an"));

        // Zeit-Optionen
        inv.setItem(10, MainGui.makeItem(Material.GREEN_STAINED_GLASS_PANE, "§a§l10 Minuten", "§7Kurzes Spiel"));
        inv.setItem(11, MainGui.makeItem(Material.GREEN_STAINED_GLASS_PANE, "§a§l20 Minuten", "§7Kurzes Spiel"));
        inv.setItem(12, MainGui.makeItem(Material.YELLOW_STAINED_GLASS_PANE, "§e§l30 Minuten", "§7Normales Spiel"));
        inv.setItem(13, MainGui.makeItem(Material.YELLOW_STAINED_GLASS_PANE, "§e§l45 Minuten", "§7Normales Spiel"));
        inv.setItem(14, MainGui.makeItem(Material.ORANGE_STAINED_GLASS_PANE, "§6§l60 Minuten", "§7Langes Spiel"));
        inv.setItem(15, MainGui.makeItem(Material.ORANGE_STAINED_GLASS_PANE, "§6§l90 Minuten", "§7Sehr langes Spiel"));
        inv.setItem(16, MainGui.makeItem(Material.RED_STAINED_GLASS_PANE, "§c§l120 Minuten", "§7Marathon!"));

        // Zurück
        inv.setItem(22, MainGui.makeItem(Material.ARROW, "§7§l◀ ZURÜCK", "§7Zurück zum Hauptmenü"));
    }

    public void open(Player p) {
        p.openInventory(inv);
    }

    public Inventory getInventory() { return inv; }
}
