package de.forceitembattle.gui;

import de.forceitembattle.ForceItemBattle;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class GuiListener implements Listener {

    private final ForceItemBattle plugin;

    public GuiListener(ForceItemBattle plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player p)) return;
        if (event.getCurrentItem() == null) return;

        String title = event.getView().title().toString();

        // Hauptmenü
        if (title.contains("Force Item Battle") && !title.contains("ERGEBNIS")) {
            event.setCancelled(true);
            handleMainMenu(p, event.getSlot());
            return;
        }

        // Zeit-Menü
        if (title.contains("Zeit einstellen")) {
            event.setCancelled(true);
            handleTimeMenu(p, event.getSlot());
            return;
        }

        // Ergebnis-Menü
        if (title.contains("ERGEBNISSE")) {
            event.setCancelled(true);
            handleResultMenu(p, event.getSlot());
            return;
        }
    }

    private void handleMainMenu(Player p, int slot) {
        switch (slot) {
            case 19 -> { // START
                p.closeInventory();
                plugin.getGameManager().startGame(p);
            }
            case 20 -> { // STOP
                p.closeInventory();
                plugin.getGameManager().stopGame(p);
            }
            case 21 -> { // PAUSE
                plugin.getGameManager().pauseGame(p);
                // Menü neu öffnen mit aktuellem Status
                new BukkitRunnable() {
                    @Override public void run() {
                        new MainGui(plugin).open(p);
                    }
                }.runTaskLater(plugin, 1L);
            }
            case 22 -> { // RESET
                p.closeInventory();
                plugin.getGameManager().resetGame(p);
            }
            case 23 -> { // ERGEBNISSE
                new BukkitRunnable() {
                    @Override public void run() {
                        new ResultGui(plugin, plugin.getGameManager().getResults()).open(p);
                    }
                }.runTaskLater(plugin, 1L);
            }
            case 28 -> { // JOKER
                p.closeInventory();
                plugin.getGameManager().useJoker(p);
            }
            case 29 -> { // SKIP
                p.closeInventory();
                plugin.getGameManager().skipItem(p);
            }
            case 31 -> { // ZEIT
                new BukkitRunnable() {
                    @Override public void run() {
                        new TimeGui(plugin).open(p);
                    }
                }.runTaskLater(plugin, 1L);
            }
            case 49 -> p.closeInventory(); // SCHLIESSEN
        }
    }

    private void handleTimeMenu(Player p, int slot) {
        int time = switch (slot) {
            case 10 -> 10 * 60;
            case 11 -> 20 * 60;
            case 12 -> 30 * 60;
            case 13 -> 45 * 60;
            case 14 -> 60 * 60;
            case 15 -> 90 * 60;
            case 16 -> 120 * 60;
            default -> -1;
        };

        if (time > 0) {
            plugin.getGameManager().setTimeSeconds(time);
            p.sendMessage(Component.text("§a[FIB] Zeit auf " + (time/60) + " Minuten gesetzt!"));
            // Zurück zum Hauptmenü
            new BukkitRunnable() {
                @Override public void run() { new MainGui(plugin).open(p); }
            }.runTaskLater(plugin, 1L);
        } else if (slot == 22) { // Zurück
            new BukkitRunnable() {
                @Override public void run() { new MainGui(plugin).open(p); }
            }.runTaskLater(plugin, 1L);
        }
    }

    private void handleResultMenu(Player p, int slot) {
        switch (slot) {
            case 46 -> { // Neues Spiel
                p.closeInventory();
                new BukkitRunnable() {
                    @Override public void run() { new MainGui(plugin).open(p); }
                }.runTaskLater(plugin, 1L);
            }
            case 48 -> { // Reset
                p.closeInventory();
                plugin.getGameManager().resetGame(p);
            }
            case 49 -> p.closeInventory();
            case 50 -> { // Hauptmenü
                new BukkitRunnable() {
                    @Override public void run() { new MainGui(plugin).open(p); }
                }.runTaskLater(plugin, 1L);
            }
        }
    }

    // Inventory-Check alle 20 Ticks (jede Sekunde) wenn Spieler sich bewegt
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!event.hasChangedBlock()) return;
        Player p = event.getPlayer();
        if (plugin.getGameManager().isRunning()) {
            plugin.getGameManager().checkInventory(p);
        }
    }
}
