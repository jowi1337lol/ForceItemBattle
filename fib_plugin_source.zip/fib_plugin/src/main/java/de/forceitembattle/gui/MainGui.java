package de.forceitembattle.gui;

import de.forceitembattle.ForceItemBattle;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

public class MainGui {

    private final ForceItemBattle plugin;
    private final Inventory inv;

    public static final String TITLE = "§6§l⚔ Force Item Battle";

    public MainGui(ForceItemBattle plugin) {
        this.plugin = plugin;
        this.inv = Bukkit.createInventory(null, 54, Component.text(TITLE));
        build();
    }

    private void build() {
        // Fülle mit grauem Glas
        fillWith(Material.GRAY_STAINED_GLASS_PANE, " ");

        boolean running = plugin.getGameManager().isRunning();
        boolean paused = plugin.getGameManager().isPaused();
        int timeMins = plugin.getGameManager().getTimeSeconds() / 60;

        // Titel-Item
        inv.setItem(4, makeItem(Material.NETHER_STAR, "§6§l⚔ FORCE ITEM BATTLE ⚔",
            "§7Das ultimative Item-Suchspiel",
            "§7Version 1.0"));

        // START Button
        inv.setItem(19, makeItem(Material.LIME_STAINED_GLASS_PANE,
            running ? "§7Spiel läuft bereits" : "§a§l▶ SPIEL STARTEN",
            running ? "§7Ein Spiel ist bereits aktiv" : "§7Startet das Spiel für alle Spieler!"));

        // STOP Button
        inv.setItem(20, makeItem(Material.RED_STAINED_GLASS_PANE,
            "§c§l⏹ SPIEL STOPPEN",
            "§7Beendet das laufende Spiel",
            running ? "§aSpiel läuft" : "§7Kein Spiel aktiv"));

        // PAUSE Button
        inv.setItem(21, makeItem(Material.YELLOW_STAINED_GLASS_PANE,
            paused ? "§e§l▶ FORTSETZEN" : "§e§l⏸ PAUSIEREN",
            paused ? "§7Spiel fortsetzen" : "§7Timer pausieren"));

        // RESET Button
        inv.setItem(22, makeItem(Material.ORANGE_STAINED_GLASS_PANE,
            "§6§l↺ RESET",
            "§7Alle Punkte auf 0",
            "§7Neue Items, volle Joker, Zeit neu"));

        // ERGEBNISSE Button
        inv.setItem(23, makeItem(Material.GOLD_BLOCK,
            "§6§l🏆 ERGEBNISSE",
            "§7Zeigt die aktuelle Rangliste",
            "§7mit allen Spielern"));

        // JOKER Button
        inv.setItem(28, makeItem(Material.RED_STAINED_GLASS_PANE,
            "§c§l🃏 JOKER BENUTZEN",
            "§7Überspringt dein aktuelles Item",
            "§73x pro Spiel verfügbar"));

        // SKIP Button
        inv.setItem(29, makeItem(Material.CYAN_STAINED_GLASS_PANE,
            "§b§l⏭ ITEM SKIPPEN",
            "§7Überspringt Item ohne Punkt",
            "§7Unbegrenzt verfügbar"));

        // ZEIT einstellen
        inv.setItem(31, makeItem(Material.CLOCK,
            "§e§l⏱ ZEIT: " + timeMins + " Minuten",
            "§7Klicke zum Ändern",
            "§7Aktuelle Zeit: §e" + timeMins + " Min"));

        // Schließen
        inv.setItem(49, makeItem(Material.BARRIER,
            "§4§l✖ SCHLIESSEN",
            "§7Schließt dieses Menü"));
    }

    private void fillWith(Material mat, String name) {
        ItemStack glass = makeItem(mat, name);
        for (int i = 0; i < 54; i++) {
            if (inv.getItem(i) == null) {
                inv.setItem(i, glass);
            }
        }
    }

    public static ItemStack makeItem(Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(
            net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        if (lore.length > 0) {
            List<Component> loreList = Arrays.stream(lore)
                .map(l -> Component.text(l).decoration(
                    net.kyori.adventure.text.format.TextDecoration.ITALIC, false))
                .toList();
            meta.lore(loreList);
        }
        item.setItemMeta(meta);
        return item;
    }

    public void open(Player player) {
        player.openInventory(inv);
    }

    public Inventory getInventory() {
        return inv;
    }
}
